#include "much_func.h"
using namespace std;
using namespace much;
int main() {
	//TODO
	return 0;
}
